package org.example.business;

import org.example.dataaccess.*;

import java.util.List;


public interface MetricsService {

    // Overview metrics
    ClusterOverview getClusterOverview();

    // Node metrics
    List<NodeMetric> getNodeMetrics();

    // Namespace metrics
    List<NamespaceMetric> getNamespaceMetrics();

    // Unhealthy pods
    List<UnhealthyPod> getUnhealthyPods();

    // Time-series data for charts
    ResourceUtilization getCpuUtilization(String duration);

    ResourceUtilization getMemoryUtilization(String duration);

    // Metric cards with sparklines
    MetricCard getPodCountMetric(String duration);

    MetricCard getNodeCountMetric(String duration);

    MetricCard getRequestCountMetric(String duration);
}