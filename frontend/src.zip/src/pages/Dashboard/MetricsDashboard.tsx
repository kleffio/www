import { AlertCircle, RefreshCw } from "lucide-react";
import React, { useEffect, useState } from "react";
import { MetricCard } from "../../components/MetricCard";
import { NamespacesTable } from "../../components/NamespacesTable";
import { NodesList } from "../../components/NodesList";
import { ResourceChart } from "../../components/ResourceChart";
import { metricsApi } from "../../services/metricsApi";
import type {
  ClusterOverview,
  MetricCard as MetricCardType,
  NamespaceMetric,
  NodeMetric,
  ResourceUtilization
} from "../../types/metrics";
import "./MetricsDashboard.css";

export const MetricsDashboard: React.FC = () => {
  const [overview, setOverview] = useState<ClusterOverview | null>(null);
  const [requestsMetric, setRequestsMetric] = useState<MetricCardType | null>(null);
  const [podsMetric, setPodsMetric] = useState<MetricCardType | null>(null);
  const [nodesMetric, setNodesMetric] = useState<MetricCardType | null>(null);
  const [cpuData, setCpuData] = useState<ResourceUtilization | null>(null);
  const [memoryData, setMemoryData] = useState<ResourceUtilization | null>(null);
  const [nodes, setNodes] = useState<NodeMetric[]>([]);
  const [namespaces, setNamespaces] = useState<NamespaceMetric[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  const fetchData = async () => {
    try {
      setError(null);
      const [
        overviewRes,
        requestsRes,
        podsRes,
        nodesMetricRes,
        cpuRes,
        memoryRes,
        nodesRes,
        namespacesRes
      ] = await Promise.all([
        metricsApi.getOverview(),
        metricsApi.getRequestsMetric("1h"),
        metricsApi.getPodsMetric("1h"),
        metricsApi.getNodesMetric("1h"),
        metricsApi.getCpuUtilization("1h"),
        metricsApi.getMemoryUtilization("1h"),
        metricsApi.getNodes(),
        metricsApi.getNamespaces()
      ]);

      setOverview(overviewRes.data);
      setRequestsMetric(requestsRes.data);
      setPodsMetric(podsRes.data);
      setNodesMetric(nodesMetricRes.data);
      setCpuData(cpuRes.data);
      setMemoryData(memoryRes.data);
      setNodes(nodesRes.data);
      setNamespaces(namespacesRes.data);
      setLastUpdate(new Date());
    } catch (err) {
      setError("Failed to fetch metrics. Check if backend is running on port 8080.");
      console.error("Error fetching metrics:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="metrics-dashboard">
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">Metrics Overview</h1>
          <p className="dashboard-subtitle">Monitor your Kubernetes cluster metrics</p>
        </div>
        <button className="refresh-button" onClick={fetchData} disabled={loading}>
          <RefreshCw size={18} className={loading ? "spinning" : ""} />
          <span>Refresh</span>
        </button>
      </div>

      {error && (
        <div className="error-banner">
          <AlertCircle size={20} />
          <span>{error}</span>
        </div>
      )}

      <div className="metrics-grid">
        {requestsMetric && <MetricCard metric={requestsMetric} loading={loading} />}
        {podsMetric && <MetricCard metric={podsMetric} loading={loading} />}
        {nodesMetric && <MetricCard metric={nodesMetric} loading={loading} />}
        {overview && overview.cpuUsagePercent != null && (
          <MetricCard
            metric={{
              title: "CPU Usage",
              value: `${overview.cpuUsagePercent.toFixed(1)}%`,
              rawValue: overview.cpuUsagePercent,
              changePercent: "+0.0%",
              changeLabel: "Cluster average",
              status: overview.cpuUsagePercent > 80 ? "critical" : "good",
              sparkline: []
            }}
            loading={loading}
          />
        )}
      </div>

      <div className="charts-section">
        <h2 className="section-title">Performance</h2>
        <div className="charts-grid">
          {cpuData && (
            <ResourceChart
              title="CPU Utilization"
              data={cpuData}
              color="#fb923c"
              loading={loading}
            />
          )}
          {memoryData && (
            <ResourceChart
              title="Memory Utilization"
              data={memoryData}
              color="#10b981"
              loading={loading}
            />
          )}
        </div>
      </div>

      <div className="infrastructure-section">
        <h2 className="section-title">Infrastructure</h2>
        <div className="infrastructure-grid">
          <NodesList nodes={nodes} loading={loading} />
          <NamespacesTable namespaces={namespaces} loading={loading} />
        </div>
      </div>

      <div className="dashboard-footer">
        <span className="last-update">Last updated: {lastUpdate.toLocaleTimeString()}</span>
      </div>
    </div>
  );
};
