import React from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import type { ResourceUtilization } from "../types/metrics";
import "./ResourceChart.css";

interface Props {
  title: string;
  data: ResourceUtilization;
  color?: string;
  loading?: boolean;
}

export const ResourceChart: React.FC<Props> = ({ title, data, color = "#fbbf24", loading }) => {
  if (loading) {
    return (
      <div className="resource-chart loading">
        <div className="chart-skeleton"></div>
      </div>
    );
  }

  const chartData =
    data.history?.map((point) => ({
      time: new Date(point.timestamp).toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit"
      }),
      value: point.value
    })) || [];

  return (
    <div className="resource-chart">
      <div className="chart-header">
        <h3 className="chart-title">{title}</h3>
        <div className="chart-stats">
          <div className="stat-value">{data.currentValue?.toFixed(1) ?? "0.0"}%</div>
          <div className={`stat-change ${data.trend || "stable"}`}>
            {(data.changePercent ?? 0) > 0 ? "+" : ""}
            {data.changePercent?.toFixed(1) ?? "0.0"}%
          </div>
        </div>
      </div>

      <div className="chart-container">
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id={`gradient-${title}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.3} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="time" stroke="#a0a0a0" style={{ fontSize: "12px" }} tickLine={false} />
            <YAxis
              stroke="#a0a0a0"
              style={{ fontSize: "12px" }}
              tickLine={false}
              domain={[0, 100]}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1a1a1a",
                border: "1px solid #333",
                borderRadius: "8px",
                color: "#fff"
              }}
              formatter={(value: number) => [`${value?.toFixed(2) ?? "0.00"}%`, "Usage"]}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke={color}
              strokeWidth={2}
              fill={`url(#gradient-${title})`}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
