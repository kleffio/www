import { useProjectsContext } from "@features/projects/context/ProjectsContext";

export const useProjects = useProjectsContext;
