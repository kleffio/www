export interface SettingsAuditItem {
  action: string;
  userMeta: string;
  timestring: string;
}
