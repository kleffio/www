export interface ProjectUsage {
  projectID: string;
  memoryUsageGB: number;
  cpuRequestCores: number;
  window: string;
}
