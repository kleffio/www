export interface ProjectUsageMetrics {
  projectID: string;
  memoryUsageGB: number;
  cpuRequestCores: number;
  window: string;
}
