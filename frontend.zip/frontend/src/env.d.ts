interface ImportMetaEnv {
  readonly VITE_BACKEND_URL?: string;
  readonly VITE_AUTH_CLIENT_ID?: string;
}
